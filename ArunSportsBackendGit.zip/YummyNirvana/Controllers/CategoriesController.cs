﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ArunSportsShop.Aspects;
using ArunSportsShop.Data;
using ArunSportsShop.Models;
using ArunSportsShop.Repositories.CategoryRepository;
using ArunSportsShop.Services.CategoryService;

namespace ArunSportsShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("policy")]
    [ExceptionHandler]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategoryService _service;
        public CategoriesController(ICategoryService service)
        {
            _service = service;
        }


        [HttpGet("{id}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetCategory(int id)
        {
            return Ok(await _service.GetCategory(id));
        }

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetCategories()
        { 
            return Ok(await _service.GetCategories());
        }


        [HttpPost("addCategory")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> AddCategory([FromBody]Category category)
        {
            await _service.AddCategory(category);
            return StatusCode(StatusCodes.Status201Created);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateCategory(int id,[FromBody]Category category)
        {
            await _service.UpdateCategory(id, category);
            return Ok();
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]

        public async Task<IActionResult> DeleteCategory(int id)
        {
            await _service.DeleteCategory(id);
            return Ok("Category deleted successfully");
        }

    }
}
