﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ArunSportsShop.Aspects;
using ArunSportsShop.Models;
using ArunSportsShop.Repositories.UserRepository;
using ArunSportsShop.Services.UserServices;

namespace ArunSportsShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("policy")]
    [ExceptionHandler]
    public class UsersController : ControllerBase
    {
        private readonly IUserService _service;
        public UsersController(IUserService service)
        {
            _service = service;
            
        }


        
        [HttpPost("register")]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody]User user)
        {

            await _service.Register(user);
            return StatusCode(StatusCodes.Status201Created, "User registered successfully");
        }

        [HttpPost("login")]
        [AllowAnonymous]
        public async Task<IActionResult> Login(Login user)
        {
            var userDetails = await _service.validateUser(user);
            var jwt =await _service.Login(user);

            return Ok(new { jwt,userDetails});
        }


        [HttpGet]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> GetUsers()
        {
            return Ok(await _service.GetUsers());
        }


        [HttpGet("{id}")]
        [Authorize]
        public async Task<IActionResult> GetUser(int id)
        {
            return Ok(await _service.GetUser(id));
        }

        
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] User user)
        {
            return Ok(await _service.UpdateUser(id, user));
        }


        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteUser(int id)
        {
            await _service.DeleteUser(id);
            return Ok("User Deleted Successfully");
        }


    }
}
