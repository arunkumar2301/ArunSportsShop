﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.CompilerServices;
using ArunSportsShop.Aspects;
using ArunSportsShop.Models;
using ArunSportsShop.Services.OrderService;

namespace ArunSportsShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("policy")]
    [ExceptionHandler]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderService _service;
        public OrdersController(IOrderService service)
        {
            _service = service;
        }
        [HttpPost("[action]")]
        [Authorize(Roles ="User")]
        public async Task<IActionResult> PlaceOrder(int userId)
        {
            var order = await _service.PlaceOrder(userId);
            return StatusCode(StatusCodes.Status201Created, order);
        }

        [HttpGet]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> GetOrders()
        {
            return Ok(await _service.GetOrders());
        }

        [HttpGet("{id}")]
        [Authorize]
        public async Task<IActionResult> GetOrder(int id)
        {
            return Ok(await _service.GetOrder(id));
        }

        [HttpPut("{id}")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> EditOrder(int id, Order order)
        {
            return Ok(await _service.EditOrder(id, order));

        }
        

        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            await _service.DeleteOrder(id);
            return Ok("Order deleted successfully");
        }

        [HttpGet("totalordercount")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetOrderCount()
        {
            return Ok(await _service.GetOrderCount());
        }

        [HttpGet("[action]")]
        [Authorize(Roles = "User")]
        public async Task<IActionResult> GetOrdersByUser(int userId)
        {
            return Ok(await _service.GetOrdersByUser(userId));
        }
    }
}
