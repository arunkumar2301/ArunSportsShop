﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ArunSportsShop.Aspects;
using ArunSportsShop.Models;
using ArunSportsShop.Services.CartService;
using ArunSportsShop.Services.ProductServices;

namespace ArunSportsShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("policy")]
    [ExceptionHandler]
    public class CartsController : ControllerBase
    {
        private readonly ICartService _service;

        public CartsController(ICartService service)
        {
            _service = service;

        }

        [HttpGet]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> GetCarts() 
        {
            return Ok(await _service.GetCarts());
        }

        [HttpGet("[action]")]
        [Authorize(Roles ="User")]
        public async Task<IActionResult> GetCartsByUser(int userId)
        {
            var carts = await _service.GetCartsByUser(userId);
            return Ok(carts);          
        }

        [HttpPost]
        [Authorize(Roles ="User")]
        public async Task<IActionResult> AddCart([FromBody]Cart cart)
        {
            
            await _service.AddCart(cart);
            return StatusCode(StatusCodes.Status201Created,"cart added successfully");            
        }

        [HttpPut("{id}")]
        [Authorize(Roles ="User")]
        public async Task<IActionResult> EditCart(int id,[FromBody]Cart cart)
        {
            await _service.EditCart(id, cart);
                return StatusCode(StatusCodes.Status201Created);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles ="User")]
        public async Task<IActionResult> DeleteCart(int id)
        {
            return Ok(await _service.DeleteCart(id));
        }


    }
}
