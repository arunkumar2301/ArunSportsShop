﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ArunSportsShop.Aspects;
using ArunSportsShop.Models;
using ArunSportsShop.Repositories.ProductRepository;
using ArunSportsShop.Services.ProductServices;

namespace ArunSportsShop.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("policy")]
    [ExceptionHandler]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _service;
        public ProductsController(IProductService service)
        {
           _service = service;
        }
        

        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetProducts()
        {
            return Ok(await _service.GetProducts());
        }

        [HttpGet("[action]")]
        [AllowAnonymous]
        public async Task<IActionResult> GetProductsByCategory(int categoryId) 
        {
            return Ok(await _service.GetProductsByCategory(categoryId));
        }

        [HttpGet("[action]")]
        [AllowAnonymous]
        public async Task<IActionResult> SearchProductsByName(string name)
        {
            return Ok(await _service.SearchProductsByName(name));
        }

        [HttpGet("[action]")]
        [AllowAnonymous]
        public async Task<IActionResult> GetProduct(int id)
        {
            return Ok(await _service.GetProduct(id));
        }
        [HttpPost]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> AddProduct([FromBody]Product product)
        {
            await _service.AddProduct(product);
            return StatusCode(StatusCodes.Status201Created);
        }

        [HttpPut("{id}")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> UpdateProduct(int id,[FromBody]Product product)
        {
            await _service.UpdateProduct(id, product);
            return StatusCode(StatusCodes.Status201Created);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            await _service.DeleteProduct(id);
            return Ok();
        }






    }
}
