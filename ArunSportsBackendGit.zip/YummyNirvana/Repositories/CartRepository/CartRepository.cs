﻿using Microsoft.EntityFrameworkCore;
using ArunSportsShop.Data;
using ArunSportsShop.Exceptions;
using ArunSportsShop.Models;

namespace ArunSportsShop.Repositories.CartRepository
{
    public class CartRepository : ICartRepository
    {
        private readonly ArunSportsShopContext _context;
        public CartRepository(ArunSportsShopContext context)
        {
            _context = context;
        }

        public async Task<List<Cart>> GetCarts()
        {
            return await _context.Carts.ToListAsync();
        }

        public async Task<List<Cart>> GetCartsByUser(int userId)
        {
            return await _context.Carts.Where(c=>c.UserId==userId).ToListAsync();
            
           
        }

        public async Task<Cart> GetCart(int id)
        {
            return await _context.Carts.FindAsync(id);
        }

        public async Task<Cart> AddCart(Cart cart)
        {
            var product = await _context.Products.FindAsync(cart.ProductId);
            var user = await _context.Users.FindAsync(cart.UserId);
            if (product == null || user == null)
            {
                throw new NoItemsInCartException("Please add any items to cart");
            }
            if(cart.Quantity > product.ProductQuantity)
            {
                throw new ProductOutOfStockException("Product is out of stock");
            }
            var cartExists = await _context.Carts.Where(c => c.UserId == cart.UserId && c.ProductId == cart.ProductId).FirstOrDefaultAsync();
            if(cartExists != null)
            {
                cartExists.Quantity += cart.Quantity;
                cartExists.Price = cartExists.Quantity * product.ProductPrice;
                await _context.SaveChangesAsync();
                return cart;
            }
            await _context.Carts.AddAsync(cart);
            cart.Price = cart.Quantity * product.ProductPrice;
            await _context.SaveChangesAsync();
            return cart;
        }

        public async Task<Cart> EditCart(int id, Cart cart)
        {
            var car = await _context.Carts.FindAsync(id);
            if(car != null)
            {
                 car.Quantity = cart.Quantity;
                await _context.SaveChangesAsync();
            }
            return car;
        }

        public async Task<Cart> DeleteCart(int id)
        {
            var cart = await _context.Carts.FindAsync(id);
            _context.Carts.Remove(cart);
            await _context.SaveChangesAsync();
            return cart;
        }
    }
}
