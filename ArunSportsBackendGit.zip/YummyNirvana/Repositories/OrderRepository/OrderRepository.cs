﻿using Microsoft.EntityFrameworkCore;
using ArunSportsShop.Data;
using ArunSportsShop.Models;

namespace ArunSportsShop.Repositories.OrderRepository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ArunSportsShopContext _context;
        public OrderRepository(ArunSportsShopContext context)
        {
            _context = context;
        }

        public async Task<bool> DeleteOrder(int id)
        {
            var ord = await _context.Orders.FindAsync(id);
            if (ord == null)
            {
                return false;
            }
            _context.Orders.Remove(ord);
            return await _context.SaveChangesAsync() == 1;

        }

        
        public async Task<Order> EditOrder(int id,Order order)
        {
            var ord = await _context.Orders.FindAsync(id);
            if(ord != null)
            {
                ord.Status = order.Status;
                await _context.SaveChangesAsync();

            }
            return ord;
        }

        public async Task<Order> GetOrder(int id)
        {
            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.OrderId == id);

            return order;
        }

        public async Task<List<Order>> GetOrders()
        {
            return await _context.Orders
                .ToListAsync();
        }

        public async Task<Order> PlaceOrder(int userId)
        {
            var userCarts = await _context.Carts
                .Include(c => c.Product)
                .Where(c => c.UserId == userId)
                .ToListAsync();
            if(userCarts.Count == 0)
            {
                return null;
            }
            double totalOrderAmount = userCarts.Sum(c => c.Price);
            var orderdetail = "";
            foreach (var cart in userCarts)
            {
                var product = await _context.Products.FindAsync(cart.ProductId);
                orderdetail += $"{product.ProductName}(x{cart.Quantity}),";
            }
            var order = new Order
            {
                UserId = userId,
                OrderDetail=orderdetail,
                OrderAmount = totalOrderAmount,
                OrderDate = DateTime.Now,
                Carts = userCarts
            };
            await _context.AddAsync(order);
            await _context.SaveChangesAsync();

            foreach(var item in userCarts)
            {
                var product = await _context.Products.FindAsync(item.Product.ProductId);
                product.ProductQuantity -= item.Quantity;
                await _context.SaveChangesAsync();
            }

            _context.Carts.RemoveRange(userCarts);
            await _context.SaveChangesAsync();
            return order;
            
            
        }

        public async Task<int> GetOrderCount()
        {
            return await _context.Orders.CountAsync();
        }

        public async Task<List<Order>> GetOrdersByUser(int userId)
        {
            return await _context.Orders.Where(o => o.UserId == userId).ToListAsync();
        }
    }
}
