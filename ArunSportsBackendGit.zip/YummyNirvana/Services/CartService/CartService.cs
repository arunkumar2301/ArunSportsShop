﻿using Microsoft.EntityFrameworkCore;
using ArunSportsShop.Exceptions;
using ArunSportsShop.Models;
using ArunSportsShop.Repositories.CartRepository;
using ArunSportsShop.Repositories.ProductRepository;

namespace ArunSportsShop.Services.CartService
{
    public class CartService : ICartService
    {
        private readonly ICartRepository _repository;
        private readonly IProductRepository _productRepository;
        public CartService(ICartRepository repository,IProductRepository productRepository)
        {
            _repository = repository;
            _productRepository = productRepository;
            
        }
        
        public async Task<List<Cart>> GetCarts()
        {
            var carts =  await _repository.GetCarts();
            if(carts.Count() == 0)
            {
                throw new CartNotFoundException("No carts found");
            }
            return carts;
        }

        public async Task<List<Cart>> GetCartsByUser(int userId)
        {
            var carts = await _repository.GetCartsByUser(userId);
            return carts;
        }

        public async Task<Cart> AddCart(Cart cart)
        {
            var product = await _productRepository.GetProduct(cart.ProductId);
            if(product == null)
            {
                throw new ProductNotFoundException("Product id not found");
            }
            else
            {
                cart.Price = cart.Quantity * product.ProductPrice;
            }
            return await _repository.AddCart(cart);
        }

        public async Task<Cart> EditCart(int id, Cart cart)
        {
            var car = await _repository.EditCart(id,cart);
            if(car == null)
            {
                throw new CartNotFoundException("Cart is not found with this id");
            }
            return car;
        }

        public async Task<Cart> DeleteCart(int id)
        {
            var cart = await _repository.GetCart(id);
            if(cart == null)
            {
                throw new CartNotFoundException("Cart with this not found");
            }
            return await _repository.DeleteCart(id);
        }
    }
}
