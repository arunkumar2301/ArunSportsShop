﻿using ArunSportsShop.Models;

namespace ArunSportsShop.Services.CartService
{
    public interface ICartService
    {
        Task<List<Cart>> GetCarts();
        Task<List<Cart>> GetCartsByUser(int userId);
        Task<Cart> AddCart(Cart cart);
        Task<Cart> EditCart(int id,Cart cart);
        Task<Cart> DeleteCart(int id);
    }
}
