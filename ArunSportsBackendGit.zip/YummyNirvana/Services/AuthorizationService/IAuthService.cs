﻿using ArunSportsShop.Models;

namespace ArunSportsShop.Services.AuthorizationService
{
    public interface IAuthService
    {
        Task<string> Authorize(Login user,string userRole);
    }
}
