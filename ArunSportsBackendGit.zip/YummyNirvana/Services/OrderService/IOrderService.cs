﻿using ArunSportsShop.Models;

namespace ArunSportsShop.Services.OrderService
{
    public interface IOrderService
    {
        Task<Order> PlaceOrder(int userId);
        Task<List<Order>> GetOrders();
        Task<Order> GetOrder(int id);
        Task<Order> EditOrder(int id,Order order);
        Task<bool> DeleteOrder(int id);
        Task<int> GetOrderCount();
        Task<List<Order>> GetOrdersByUser(int userId);
    }
}
