﻿using Microsoft.Identity.Client;
using System.Runtime.CompilerServices;
using ArunSportsShop.Exceptions;
using ArunSportsShop.Models;
using ArunSportsShop.Repositories.OrderRepository;

namespace ArunSportsShop.Services.OrderService
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _repository;
        public OrderService(IOrderRepository repository)
        {
            _repository = repository;
        }

        public async Task<bool> DeleteOrder(int id)
        {
            var ord = await _repository.DeleteOrder(id);
            if (!ord)
            {
                throw new OrderNotFoundException("Order with this id not found");
            }
            return true;

        }

        
        

        public async Task<Order> GetOrder(int id)
        {
            var order = await _repository.GetOrder(id);
            if(order == null)
            {
                throw new OrderNotFoundException("Order with this id not found");
            }
            return order;
        }

        public async Task<int> GetOrderCount()
        {
            return await _repository.GetOrderCount();
        }

        public async Task<List<Order>> GetOrders()
        {
            var orders = await _repository.GetOrders();
            if(orders.Count() == 0)
            {
                throw new OrderNotFoundException("No orders found");
            }
            return orders;
        }

        public async Task<Order> PlaceOrder(int userId)
        {
            var order = await _repository.PlaceOrder(userId);
            if(order == null)
            {
              throw new NoItemsInCartException("No items in cart");
            
            }
            return order;
        }

        public async Task<List<Order>> GetOrdersByUser(int userId)
        {
            return await _repository.GetOrdersByUser(userId);
        }

        public async Task<Order> EditOrder(int id, Order order)
        {
            return await _repository.EditOrder(id, order);
        }
    }
}
