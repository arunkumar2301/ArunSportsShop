﻿using Microsoft.EntityFrameworkCore;
using ArunSportsShop.Configurations;
using ArunSportsShop.Models;

namespace ArunSportsShop.Data
{
    public class ArunSportsShopContext : DbContext
    {
        public ArunSportsShopContext()
        {
        }

        public ArunSportsShopContext(DbContextOptions<ArunSportsShopContext> options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Cart> Carts { get; set; }
        public DbSet<Order> Orders { get; set; }
        //public DbSet<CartProductMap> CartProductMaps { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.ApplyConfiguration(new CategoriesConfiguration());
            modelBuilder.ApplyConfiguration(new CartsConfiguration());
            modelBuilder.ApplyConfiguration(new ProductsConfiguration());
            modelBuilder.ApplyConfiguration(new CartsConfiguration());
            //modelBuilder.ApplyConfiguration(new CartProductMapConfiguration());
            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
            base.OnConfiguring(optionsBuilder);
        }

        

    }
}
