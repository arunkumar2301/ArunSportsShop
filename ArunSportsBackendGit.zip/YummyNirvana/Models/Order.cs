﻿using System.Net.Http.Headers;

namespace ArunSportsShop.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public string? OrderDetail { get; set; }
        public string? Status { get; set; } = "Pending";
        public DateTime OrderDate { get; set; }
        public double OrderAmount { get; set; }
        
        public int UserId { get; set; }
        public virtual User? User { get; set; }
        public virtual List<Cart>? Carts { get; set; }
        
    }
}
