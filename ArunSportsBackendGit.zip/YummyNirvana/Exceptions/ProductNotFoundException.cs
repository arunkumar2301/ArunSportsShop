﻿using Microsoft.AspNetCore.Mvc.Diagnostics;

namespace ArunSportsShop.Exceptions
{
    public class ProductNotFoundException : ApplicationException
    {
        public ProductNotFoundException(string msg) : base(msg)
        {
            
        }
        public ProductNotFoundException()
        {
            
        }
    }
}
