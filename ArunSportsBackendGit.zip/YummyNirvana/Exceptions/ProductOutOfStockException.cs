﻿namespace ArunSportsShop.Exceptions
{
    public class ProductOutOfStockException : ApplicationException
    {
        public ProductOutOfStockException(string msg) : base(msg)
        {
            
        }
        public ProductOutOfStockException()
        {
            
        }
    }
}
