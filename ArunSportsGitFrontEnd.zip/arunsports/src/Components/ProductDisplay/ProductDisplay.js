import axios from 'axios'
import React, { useEffect, useState } from 'react'
import ProductItem from 'C:/Users/2318911/ArunSports/arunsports/src/Components/ProductItem/ProductItem.js'
import './ProductDisplay.css'

const ProductDisplay = ({cat,setShowLogin}) => {
    const [products,setProducts] = useState([
        {
            productId:0,
            productName:'',
            productDescription:'',
            productPrice:0,
            imageUrl:'',
            categoryId:0
        }
    ])


    useEffect(()=>{
        axios.get("https://localhost:7243/api/Products").then((resp)=>{setProducts(resp.data)})

    })

  return (
    <div className='Product-display' id='Product-display'>
        <h2>Give A Choices</h2>
        <div className='Product-display-list'>
            {products.map((product) => {
                
                if (cat===0 || cat===product.categoryId ) {
                    return <ProductItem setShowLogin={setShowLogin} key={product.productId} id={product.productId} name={product.productName} description={product.productDescription} price={product.productPrice} image={product.imageUrl} />
                }
            })}
            </div>     
    </div>
  )
}

export default ProductDisplay;
