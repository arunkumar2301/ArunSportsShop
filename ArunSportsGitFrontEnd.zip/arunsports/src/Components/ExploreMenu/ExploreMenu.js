import axios from 'axios'
import React, { useState, useEffect } from 'react'
import './ExploreMenu.css'

const ExploreMenu = ({cat,setCategory}) => {
    const [categories, setCategories] = useState([
        {
        categoryId:0,
        categoryName:'',
        imageUrl:''
    }]
)

    useEffect(()=>{
        axios.get("https://localhost:7243/api/Categories").then((resp)=>{setCategories(resp.data)})
    })

  return (
    <div className='explore-menu' id='explore-menu'>
        <h1>Explore Our Sports Product</h1>
        <p className='explore-menu-text'>This includes clothing and footwear designed for physical activities. It ranges from jerseys and shorts for various sports to specialized footwear like cleats and running shoes.</p>
        <div className='explore-menu-list'>
            {categories.map(category =>  (
                    <div onClick={()=>setCategory(prev=>prev===category.categoryId?0:category.categoryId)} key={category.categoryId} className='explore-menu-list-item'>
                        <img className={cat===category.categoryId?"active":""} src={category.imageUrl} alt='' />
                        <p>{category.categoryName}</p> 
                        </div>
                )
            )}

        </div>
      <hr />
    </div>
  )
}

export default ExploreMenu
