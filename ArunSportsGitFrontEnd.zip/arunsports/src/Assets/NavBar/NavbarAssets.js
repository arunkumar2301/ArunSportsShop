import logo from './ArunSportsLogo.png'
import basket_icon from './basket_icon.png'
import profile_icon from './profile_icon.png'
import search_icon from './search_icon.png'
import cross_icon from './cross_icon.png'
import add_icon_green from './add_icon_green.png'
import add_icon_white from './add_icon_white.png'
import remove_icon_red from './remove_icon_red.png'
import logout_icon from './logout_icon.png'
import bag_icon from './bag_icon.png'

export const NavbarAssets = {
    logo,
    basket_icon,
    profile_icon,
    search_icon,
    cross_icon,
    add_icon_green,
    add_icon_white,
    remove_icon_red,
    logout_icon,
    bag_icon
}
