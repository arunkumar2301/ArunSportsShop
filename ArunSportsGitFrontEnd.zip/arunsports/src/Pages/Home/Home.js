import React, { useState } from 'react'
import './Home.css'
import Header from '../../Components/Header/Header'
import ExploreMenu from '../../Components/ExploreMenu/ExploreMenu'

import Footer from '../../Components/Footer/Footer'
import ProductDisplay from '../../Components/ProductDisplay/ProductDisplay'


const Home = ({ setShowLogin }) => {
  const [cat, setCategory] = useState(0);
  return (
    <div>
      <Header />
      <ExploreMenu cat={cat} setCategory={setCategory} />
      <ProductDisplay setShowLogin={setShowLogin} cat={cat} />
      <Footer />
    </div>
  )
}

export default Home
